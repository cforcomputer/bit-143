#define TESTING
using System;
using System.Collections.Generic;

/*
 * STUDENTS: Your answers (your code) goes into this file!!!!
 * 
  * NOTE: In addition to your answers, this file also contains a 'main' method, 
 *      in case you want to run a normal console application.
 * 
 * If you want to / have to put something into 'Main' for these PCEs, then put that 
 * into the Program.Main method that is located below, 
 * then select this project as startup object 
 * (Right-click on the project, then select 'Set As Startup Object'), then run it 
 * just like any other normal, console app: use the menu item Debug->Start Debugging, or 
 * Debug->Start Without Debugging
 * 
 */

namespace PCE_StarterProject
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello, world!");

            BinarySearchTree bst = new BinarySearchTree();

        }
    }
    public class BinarySearchTree
    {
        // Protected so that the BST_Verifier subclass can get at it
        // and verify that the tree looks right (for NUnit tests)
        // Normally this should be private.
        protected BSTNode top; // also (semi-)traditional to name this 'root', instead of 'top'

        // You should make the BSTNode class a nested class
        // Normally should be private; it's protected for the reasons explained above
        protected class BSTNode
        {
            public BSTNode Left;
            public BSTNode Right;
            public int Data;
            public BSTNode(int val)
            {
                Data = val;
            }
        }

        public void Add(int newValueToAdd)
        {

        }

        public bool Find(int target)
        {
            if (top == null)
                return true;
            return false;
        }

        public void Print()
        {
            Console.WriteLine("PRINT IS NOT YET IMPLEMENTED!!!!\nYou need to implement this method, recursively!");
        }
        private void Print(BSTNode cur)
        {
        }


        public void PrintIterative()
        {
            Stack<BSTNode> s = new Stack<BSTNode>();
            Console.WriteLine("PRINT IS NOT YET IMPLEMENTED!!!!\nYou need to implement this method, iteratively (using a loop)!");
        }


        public bool FindR(int target)
        {
            // non-working:
            if (top == null)
                return true;
            return false;
        }
        private bool FindR(int target, BSTNode cur)
        {
            return false;
        }

        public void AddR(int newValueToAdd)
        {
        }
        private void AddR(BSTNode cur, BSTNode nodeToAdd)
        {

        }

        public void PrintBeneathNode(int target)
        {
            Console.WriteLine("NOT YET IMPLEMENTED");
            return;

        }
    }
}