using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// Answer: The program will not compile because:
///   case MenuOptions.RUN_TESTS:
///   AllTests tester = new AllTests();
///   tester.RunTests();
///   break;
///   Is not implemented correctly. For this particular problem I merely commented it out
///   and left a note for when it would be necessary for later implementing tests. In a professional 
///   environment I would likely be using some kind of version control system and code review.
///   I could submit an issue inquiring to the purpose of the code. If I was working with a team, I could
///   also ask someone nearby for assistance. 

namespace MulitList_Starter
{
    class Program
    {
        static void Main(string[] args)
        {
            (new UserInterface()).RunProgram();

            // Or, you could go with the more traditional:
            // UserInterface ui = new UserInterface();
            // ui.RunProgram();
        }
    }

    // Bit of a hack, but still an interesting idea....
    enum MenuOptions
    {
        // DO NOT USE ZERO!
        // (TryParse will set choice to zero if a non-number string is typed,
        // and we don't want to accidentally set nChoice to be a member of this enum!)
        QUIT = 1,
        ADD_BOOK,
        PRINT,
        REMOVE_BOOK,
        RUN_TESTS
    }

    class UserInterface
    {
        MultiLinkedListOfBooks theList;

        public void RunProgram()
        {
            int nChoice;
            theList = new MultiLinkedListOfBooks();



            do // main loop
            {
                Console.WriteLine("Your options:");
                Console.WriteLine("{0} : End the program", (int)MenuOptions.QUIT);
                Console.WriteLine("{0} : Add a book", (int)MenuOptions.ADD_BOOK);
                Console.WriteLine("{0} : Print all books", (int)MenuOptions.PRINT);
                Console.WriteLine("{0} : Remove a Book", (int)MenuOptions.REMOVE_BOOK);
                Console.WriteLine("{0} : RUN TESTS", (int)MenuOptions.RUN_TESTS);
                if (!Int32.TryParse(Console.ReadLine(), out nChoice))
                {
                    Console.WriteLine("You need to type in a valid, whole number!");
                    continue;
                }
                switch ((MenuOptions)nChoice)
                {
                    case MenuOptions.QUIT:
                        Console.WriteLine("Thank you for using the multi-list program!");
                        break;
                    case MenuOptions.ADD_BOOK:
                        this.AddBook();
                        break;
                    case MenuOptions.PRINT:
                        theList.Print();
                        break;
                    case MenuOptions.REMOVE_BOOK:
                        this.RemoveBook();
                        break;
                    case MenuOptions.RUN_TESTS:
                        //AllTests tester = new AllTests();
                        //tester.RunTests();
                        break;
                    default:
                        Console.WriteLine("I'm sorry, but that wasn't a valid menu option");
                        break;

                }
            } while (nChoice != (int)MenuOptions.QUIT);
        }

        public void AddBook()
        {
            Console.WriteLine("ADD A BOOK!");

            Console.WriteLine("Author name?");
            string author = Console.ReadLine();

            Console.WriteLine("Title?");
            string title = Console.ReadLine();

            double price = -1;
            while (price < 0)
            {
                Console.WriteLine("Price?");
                if (!Double.TryParse(Console.ReadLine(), out price))
                {
                    Console.WriteLine("I'm sorry, but that's not a number!");
                    price = -1;
                }
                else if (price < 0)
                {
                    Console.WriteLine("I'm sorry, but the number must be zero, or greater!!");
                }
            }

            ErrorCode ec = theList.Add(author, title, price);

            if (ec == ErrorCode.DuplicateBook)
            {
                Console.WriteLine(" \n Duplicate Book!");
            }
            else
            {
                Console.WriteLine(" \n Book Added!");
            }

            // STUDENTS: YOUR ERROR-CHECKING CODE SHOULD GO HERE!
        }

        public void RemoveBook()
        {
            Console.WriteLine("REMOVE A BOOK!");

            Console.WriteLine("Author name?");
            string author = Console.ReadLine();

            Console.WriteLine("Title?");
            string title = Console.ReadLine();

            ErrorCode ec = theList.Remove(author, title);

            if (ec == ErrorCode.BookNotFound)
            {
                Console.WriteLine(" \n Sorry Book not found!");
            }
            else
            {
                Console.WriteLine(" \n Book Removed!");
            }

            // STUDENTS: YOUR ERROR-CHECKING CODE SHOULD GO HERE!
        }
    }

    enum ErrorCode
    {
        OK,
        DuplicateBook,
        BookNotFound
    }

    class MultiLinkedListOfBooks
    {

        public class Node
        {
            public Node()
            {

            }
            public Book book_object;
            public Node next = null;
        }

        Node head_node = null;

        private class Author
        {
        }
        public class Book
        {
            public string author;
            public string title;
            public double price;


            // Probably good to have a Print method on this class

            /// <summary>
            /// Compares the parameter, and this book, and determines which one should go
            /// first, in the AUTHOR list
            /// </summary>
            /// <param name="otherBook"></param>
            /// <returns> -1 if this book goes before the otherBook
            /// 0 if they're duplicate books
            /// +1 if this book goes AFTER the otherBook</returns>
            public int Compare(Book otherBook)
            {
                return 0;
            }
        }

        public ErrorCode Add(string author, string title, double price)
        {
            // If the book is already in the list (author, title), then
            // do the following:

            if (head_node != null)
            {
                int flag = 0;
                Node current_node = head_node;
                do
                {
                    if (author == current_node.book_object.author)
                    {
                        if (title == current_node.book_object.title)
                        {
                            flag = 1;
                            break;
                        }
                    }
                    current_node = current_node.next;
                }
                while (current_node != null);

                if (flag == 1)
                    return ErrorCode.DuplicateBook;
            }

            if (head_node == null)
            {
                Node newnode = new Node();
                newnode.book_object = new Book();
                newnode.book_object.author = author;
                newnode.book_object.title = title;
                newnode.book_object.price = price;
                newnode.next = null;

                head_node = newnode;

            }
            else
            {
                int flag = 0;
                Node newnode = new Node();
                newnode.book_object = new Book();
                newnode.book_object.author = author;
                newnode.book_object.title = title;
                newnode.book_object.price = price;
                newnode.next = null;
                Node current_node = head_node;
                Node prev_node = head_node;

                do
                {
                    if (author.CompareTo(current_node.book_object.author) < 0)
                    {
                        newnode.next = current_node;
                        prev_node.next = newnode;
                        //if (prev_node == head_node)
                        //{
                        // prev_node.next = newnode;
                        //}
                        //else
                        //{
                        // newnode = head_node;
                        //}
                        flag = 1;
                        break;
                    }
                    else if (author.CompareTo(current_node.book_object.author) > 0)
                    {
                        prev_node = current_node;
                        current_node = current_node.next;
                    }
                    else if (author.CompareTo(current_node.book_object.author) == 0)
                    {
                        if (title.CompareTo(current_node.book_object.title) < 0)
                        {
                            newnode.next = current_node;
                            if (prev_node != head_node)
                            {
                                prev_node.next = newnode;
                            }
                            else
                            {
                                newnode = head_node;
                            }
                            flag = 1;
                            break;
                        }
                        else
                        {
                            newnode.next = current_node.next;
                            current_node.next = newnode;
                            flag = 1;
                            break;
                        }
                    }

                }
                while (current_node != null);
                if (flag == 0)
                {
                    newnode.next = prev_node.next;
                    prev_node.next = newnode;
                }
            }

            return ErrorCode.OK;

            // having multiple books with the same author, but different titles, or
            // multiple books with the same title, but different authors, is fine.

            // two books with the same author & title should be identified as duplicates,
            // even if the prices are different.
        }

        public void Print()
        {
            if (head_node == null)
            {
                Console.WriteLine("List is Empty");
            }
            else
            {
                Node current_node = head_node;
                do
                {
                    Console.WriteLine("\nBook Author: " + current_node.book_object.author);
                    Console.WriteLine("\nBook Title: " + current_node.book_object.title);
                    Console.WriteLine("\nPrice: " + current_node.book_object.price);

                    current_node = current_node.next;

                }
                while (current_node != null);
            }
            // if there are no books, then print out a message saying that the list is empty
        }

        public ErrorCode Remove(string author, string title)
        {
            Node current_node = head_node;
            Node prev_node = head_node;
            int flag = 0;
            if (head_node != null)
            {
                do
                {

                    if (author.CompareTo(current_node.book_object.author) == 0)
                    {
                        if (title.CompareTo(current_node.book_object.title) == 0)
                        {
                            if (current_node != prev_node)
                            {
                                prev_node.next = current_node.next;
                                current_node = null;

                            }
                            else
                            {
                                if (current_node.next != null)
                                    head_node = current_node.next;
                                else
                                    head_node = null;
                                current_node = null;

                            }
                            flag = 1;
                        }
                        else
                        {
                            prev_node = current_node;
                            current_node = current_node.next;
                        }
                    }
                    else
                    {
                        prev_node = current_node;
                        current_node = current_node.next;
                    }
                }
                while (current_node != null);
            }


            // if there isn't an exact match, then do the following:
            if (flag == 0)
                return ErrorCode.BookNotFound;
            else
                return ErrorCode.OK;
            // (this includes finding a book by the given author, but with a different title,
            // or a book with the given title, but a different author)
        }
    }
}