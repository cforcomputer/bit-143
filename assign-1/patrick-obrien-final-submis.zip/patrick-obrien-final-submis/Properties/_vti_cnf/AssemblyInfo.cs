vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2017 07:21:07 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|mike-PC\\mike
vti_modifiedby:SR|mike-PC\\mike
vti_nexttolasttimemodified:TR|03 Apr 2017 05:56:36 -0000
vti_timecreated:TR|03 Apr 2017 05:56:18 -0000
vti_backlinkinfo:VX|
vti_cacheddtm:TX|03 Apr 2017 05:56:18 -0000
vti_filesize:IR|1280
