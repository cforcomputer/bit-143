// Patrick O'Brien
// BIT 143
// Summer 2019
// Assignment 1
// Revision 0

using System;

namespace Helpdesk
{
    /// <summary>
    /// Executes the program
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            UserInterface ui = new UserInterface();
            ui.RunProgram();
        }
    }
}
